import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import zscore

df = pd.read_csv('heights.csv')
Q1 = df['Height'].quantile(0.25)
Q3 = df['Height'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
df_iqr_clean = df[(df['Height'] >= lower_bound) & (df['Height'] <= upper_bound)]
df['zscore'] = zscore(df['Height'])
df_zscore_clean = df[(df['zscore'] >= -3) & (df['zscore'] <= 3)]