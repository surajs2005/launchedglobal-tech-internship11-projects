import pandas as pd

orders = pd.read_excel('Superstore_Sales.xls')
orders.drop('Row ID', axis=1, inplace=True)
orders.drop(['Order Date', 'Order Priority'], axis=1, inplace=True)
orders.drop(1, axis=0, inplace=True)
orders.drop([2, 3], axis=0, inplace=True)
print(orders.describe())