import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

tips = pd.read_csv('tips.csv')
sns.histplot(tips['tip'], kde=True)
plt.show()
sns.boxplot(x='day', y='total_bill', data=tips, hue='sex')
plt.show()