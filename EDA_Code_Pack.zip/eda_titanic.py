import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('Titanic_df.csv')
sns.countplot(x='Survived', hue='Sex', data=df)
plt.show()
sns.countplot(x='Survived', hue='Pclass', data=df)
plt.show()