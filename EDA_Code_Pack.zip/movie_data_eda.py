import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import ast

movie_data = """0 | star_rating | title | content_rating | genre | duration | actors_list
1 | 9.3 | The Shawshank Redemption | R | Crime | 142 | ['Tim Robbins', 'Morgan Freeman', 'Bob Gunton']
2 | 9.2 | The Godfather | R | Crime | 175 | ['Marlon Brando', 'Al Pacino', 'James Caan']
3 | 9.1 | The Godfather: Part II | R | Crime | 200 | ['Al Pacino', 'Robert De Niro', 'Robert Duvall']
4 | 9.0 | The Dark Knight | PG-13 | Action | 152 | ['Christian Bale', 'Heath Ledger', 'Aaron Eckhart']
5 | 8.9 | Pulp Fiction | R | Crime | 154 | ['John Travolta', 'Uma Thurman', 'Samuel L. Jackson']
6 | 8.9 | 12 Angry Men | NOT RATED | Drama | 96 | ['Henry Fonda', 'Lee J. Cobb', 'Martin Balsam']
7 | 8.9 | The Good, the Bad and the Ugly | NOT RATED | Western | 161 | ['Clint Eastwood', 'Eli Wallach', 'Lee Van Cleef']
8 | 8.9 | The Lord of the Rings: The Return of the King | PG-13 | Adventure | 201 | ['Elijah Wood', 'Viggo Mortensen', 'Ian McKellen']
9 | 8.9 | Schindler's List | R | Biography | 195 | ['Liam Neeson', 'Ralph Fiennes', 'Ben Kingsley']"""

def parse_movie_data(data):
    lines = data.strip().split('\n')
    headers = [h.strip() for h in lines[0].split(' | ')]
    rows = [[p.strip() for p in line.split(' | ')] for line in lines[1:]]
    df = pd.DataFrame(rows, columns=headers)
    df['star_rating'] = pd.to_numeric(df['star_rating'])
    df['duration'] = pd.to_numeric(df['duration'])
    df['actors_list'] = df['actors_list'].apply(ast.literal_eval)
    return df

df = parse_movie_data(movie_data)
print(df[['title', 'star_rating']].head())