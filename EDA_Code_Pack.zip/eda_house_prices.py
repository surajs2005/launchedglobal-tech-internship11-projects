import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

data = pd.read_csv('house_prices.csv')
Q1 = data['SalePrice'].quantile(0.25)
Q3 = data['SalePrice'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
clean_data = data[(data['SalePrice'] >= lower_bound) & (data['SalePrice'] <= upper_bound)]
sns.boxplot(x=clean_data['SalePrice'])
plt.show()