import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('mtcars.csv')
sns.regplot(x='wt', y='mpg', data=df)
plt.show()
sns.lmplot(x='wt', y='mpg', hue='vs', data=df, palette='Set1', markers=['o', 's'])
plt.show()