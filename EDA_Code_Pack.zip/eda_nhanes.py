import pandas as pd
import matplotlib.pyplot as plt
from pandas.plotting import parallel_coordinates

df = pd.read_csv('NHANES.csv')
subset = df[['BMXLEG', 'BMXARML', 'BMXHT', 'BMXWT', 'RIAGENDR']].dropna()
plt.figure(figsize=(12, 8))
parallel_coordinates(subset, 'RIAGENDR', color=['blue', 'violet'])
plt.show()