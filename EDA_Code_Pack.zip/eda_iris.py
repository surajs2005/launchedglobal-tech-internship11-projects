import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

iris = pd.read_csv('Iris.csv')
sns.pairplot(iris, hue='Species', palette='husl')
plt.show()
sns.jointplot(data=iris, x='SepalLengthCm', y='SepalWidthCm', hue='Species', kind='scatter')
plt.show()