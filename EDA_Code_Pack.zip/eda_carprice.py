import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('CarPrice.csv')
sns.heatmap(df.corr(numeric_only=True), annot=True, fmt=".2f")
plt.show()
sns.histplot(df['price'], kde=True)
plt.show()